import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function Calculator(navigation) {
  const [display, setDisplay] = useState('0');
  const [operator, setOperator] = useState(null);
  const [firstValue, setFirstValue] = useState(null);

  const handlePress = (value) => {
    if (value === '+' || value === '-' || value === '*' || value === '/') {
      setOperator(value);
      setFirstValue(parseFloat(display));
      setDisplay('0');
    } else if (value === '=') {
      if (operator && firstValue != null) {
        const secondValue = parseFloat(display);
        let result;
        if (operator === '+') {
          result = firstValue + secondValue;
        } else if (operator === '-') {
          result = firstValue - secondValue;
        } else if (operator === '*') {
          result = firstValue * secondValue;
        } else if (operator === '/') {
          result = firstValue / secondValue;
        }
        setDisplay(String(result));
        setOperator(null);
        setFirstValue(null);
      }
    } else if (value === 'C') {
      setDisplay('0');
      setOperator(null);
      setFirstValue(null);
    } else {
      setDisplay((prev) => (prev === '0' ? value : prev + value));
    }
  };

  const renderButton = (label) => (
    <TouchableOpacity style={styles.button} onPress={() => handlePress(label)}>
      <Text style={styles.buttonText}>{label}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.display}>{display}</Text>
      <View style={styles.row}>
        {['1', '2', '3', '+'].map(renderButton)}
      </View>
      <View style={styles.row}>
        {['4', '5', '6', '-'].map(renderButton)}
      </View>
      <View style={styles.row}>
        {['7', '8', '9', '*'].map(renderButton)}
      </View>
      <View style={styles.row}>
        {['C', '0', '=', '/'].map(renderButton)}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#282C34',
    padding: 8,
  },
  display: {
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'right',
    padding: 8,
    marginBottom: 20,
    backgroundColor: '#333',
    color: '#fff',
    borderRadius: 8,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-evenly', 
    marginBottom: 8, 
  },
  button: {
    width: 60, 
    height: 60, 
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#61DAFB',
    borderRadius: 30,
    marginHorizontal: 5, 
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
  },
  buttonText: {
    fontSize: 22, 
    color: '#fff',
    fontWeight: '600',
  },
});
